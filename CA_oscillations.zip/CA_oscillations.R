#*******************************************************************************
# 
#  manuscript:   Regionalization of climate teleconnections across Central Asian
#                mountains improves predictability of the seasonal precipitation.
#
#  description:  Script for 1) Calculation of long-term annual and seasonal 
#                climatologies for the delineated precipitation subregions;
#                2) Estimation of Spearman rank correlation between climate 
#                oscillation indices and the seasonal precipitation; 3) Running
#                SVR-based model for seasonal predictions.  
#               
#                compiled in R version 4.1.1, last run on December 10, 2021
#
#  author:       ...
#
#*******************************************************************************

### Loading/installing necessary packages

loading<-function(...) {
  libs<-unlist(list(...))
  req<-unlist(lapply(libs,require,character.only=TRUE))
  need<-libs[req==FALSE]
  if(length(need)>0){ 
    install.packages(need)
    lapply(need,require,character.only=TRUE)
  }
}

loading("rgdal","raster","rgeos", "readr", "dplyr","lubridate","anytime","tidyr",
        "RColorBrewer","gplots","gridExtra","circlize",
        "splitTools","e1071","Metrics","hydroGOF","rminer")

if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("ComplexHeatmap")

Sys.setlocale("LC_TIME", "English")

######################################################################################
## Setting the scene

# setting up the working directory

setwd(".../CA_oscillations/") # indicate here a path to unzipped "CA_oscillations" folder


#uploading shapefiles of the deliniated precipitation subregions over Tian-Shan and Pamir mountains
{
  region_polygons<-rgdal:: readOGR(dsn = ".", layer = "subregions_final")
  # x11()
  plot(region_polygons,lwd=2)
  polygonsLabel(region_polygons, labels = region_polygons$Name,
                method = "centroid",col="blue")
  region_polygons
}

# Uploading MSWEP data for the study area extent
{
MSWEP<-raster::brick('MSWEP_stack.gri')
plot(MSWEP[[12]], main="Precipitation in Dec 1980")
plot(region_polygons, add=T)


dates<-MSWEP %>% 
  names() %>% 
  gsub("X","",.) %>% 
  as.numeric(.) %>% 
  ym(.)  # string of dates
}



#################################################################################################
## Exploring the long-term climatologies for the precipitation subregions

# Estimating annual and seasonal (Feb-Jun) precipitation means:

prcp_list<-list() # this list will keep monthly precipitation averaged for each subregion
for(i in region_polygons$Name){
  
  subregion =raster::subset(region_polygons, region_polygons$Name == i)
  plot(subregion)
  print(region_polygons$Name[region_polygons$Name== i])
  
  sb_prcp <- as.data.frame(t(raster:: extract(MSWEP, subregion, fun=mean, na.rm=TRUE)))
  colnames(sb_prcp)<-i
  

  prcp_list[i]<-sb_prcp
}

{  
  annual_means<-list()
  for(i in 1:length(prcp_list)){
    average_annual<-sum(prcp_list[[i]])/41.83333 # MSWEP data is from 02/1979 until 12/2020. This constitutes 41.8333 years
    annual_means[i]<-round(average_annual,0)
  }
  
  seasonal_means<-list()
  for(i in 1:length(prcp_list)){
    reg_precip<-as.data.frame(prcp_list[[i]])
    reg_precip$Date<-dates
    colnames(reg_precip)[1]<-c(i)
    
    
    average_season<-reg_precip%>%
      filter(month(Date) %in% c(2:6))%>% 
      group_by(Date)
    average_season<-round(sum(average_season[,1])/(41),0) # mean seasonal precipitation
    seasonal_means[i]<-average_season
    
  }
  
  climatology<-as.data.frame(do.call(cbind, list(region_polygons$Name,annual_means, seasonal_means)))
  colnames(climatology)<-c("subregion","mean annual prcp (mm)","mean seasonal prcp (mm)")
  
    
  print(climatology)
}
###Long-term monthly precipitation patterns as boxplots
{
  
  
  for(i in 1:length(prcp_list)){
    prcp_subregion<-as.data.frame(prcp_list[i])
    prcp_subregion$Date<-as.Date(dates, format="%Y-%m-%d")
    
    prcp_subregion<-prcp_subregion[-(1:11),]
    
    
    m <-xts:: xts(prcp_subregion[,-c(2)], order.by= prcp_subregion$Date)
    
    cmonth <- format(time(m), "%b")
    months <- factor(cmonth, levels=unique(cmonth), ordered=TRUE)
    myColors <- ifelse(levels(months)=="Feb", "#3182bd",
                       ifelse(levels(months)=="Mar", "#3182bd", 
                              ifelse(levels(months)=="Apr", "#3182bd",
                                     ifelse(levels(months)=="May","#3182bd",
                                            ifelse(levels(months)=="Jun", "#3182bd",
                                                   "#deebf7" ) ))))
    x11()
    boxplot(zoo::coredata(m) ~ months,
            col=myColors, ylim = c(0, 200),
            ylab="",xlab="",
            outwex=T,title="TRA")
    # tick <- seq_along(GRAPH$names)
    # axis(1, at = tick, labels = F)
    title(main=paste(colnames(prcp_subregion)[1]),line=-1.5,cex.main=1.5,font.main= 1)
    
  }
}
graphics.off()
rm(prcp_subregion,cmonth,i,m, months, myColors)

########################################################################################
## Determining teleconnections between the climate oscillations and Feb-Jun precipitation


## Constructing subregions-averaged seasonal precipitation timeseries
{
  seasonal_list<-list()
  for(i in 1:length(prcp_list)){
    prcp_subregion<-as.data.frame(prcp_list[i])
    prcp_subregion$Date<-as.Date(dates, format="%Y-%m-%d")
    
    FMAMJ<-prcp_subregion%>%
      mutate(year = year(Date)) %>%
      filter(month(Date) %in% c(2:6))%>% 
      group_by(year)%>%
      summarise_at(vars(-Date), funs(sum(.)))
    seasonal_list[i]<-FMAMJ[,2]
  }
  
  seasonal_prcp<-as.data.frame(seasonal_list)
  colnames(seasonal_prcp)<-region_polygons$Name
  seasonal_prcp$year<-FMAMJ$year
  
  # print(round(seasonal_prcp[c(1:8),]))
  rm(FMAMJ,prcp_subregion,i,seasonal_list )
}

## Calculating Spearman correlation coefficients between oscillation indices at different lag-times and the seasonal precipitation 
## using SOI index as an example 

#  We will first convert MSWEP raster brick into a long dataframe
{
wide_df<-as.data.frame(MSWEP, xy=T)
colnames(wide_df)[c(1,2)]<-c("Longitude","Latitude")

long_df <-reshape2:: melt(wide_df, id.vars = c("Longitude", "Latitude"),value.name = "Total Precipitation") 
long_df$variable<-gsub("X","",long_df$variable)
long_df$variable<-anytime:: anydate(long_df$variable)
colnames(long_df)[3]<-"Time"
rm(wide_df)
}
# Constructing seasonal precipitation timeseries for each pixel
precip_sums<-long_df%>% filter(month(Time) %in% c(2:6))%>%
  group_by(Longitude,Latitude,year(Time))%>%
  summarise(Total = sum(`Total Precipitation`)) 


# upload a file with climate oscillations timeseries: 
indices <- read_csv("processed_indices.csv", 
                    col_types = cols(...1 = col_skip())) #the monthly indices are arranged in a wide table format, with each row corresponding to each observation year.
 

# Extracting monthly indices of SOI
soim1<-indices %>%
  dplyr:: select(starts_with(c("year","soi")))%>% # to check other oscillation indices replace "soi" with respective term, e.g. for use "pdo" for PDO and so on
  na.omit()


# Creating matrices of SOI indices and the seasonal precipitation timeseries, that are compatible in dimensions
{
  aa<-t(precip_sums%>% 
          tidyr::spread("year(Time)","Total")) %>% 
    as.data.frame()
  attribute<-aa[c(1:2),]
  aa$attributes<-rownames(aa)  
  
bb<-aa[-c(1:2),] %>% 
  rename(year=attributes)

bb<-merge(soim1,bb,by='year', all=T) %>% 
  na.omit()

mat1<- as.matrix(bb[,c(2:19)])  
mat2<-as.matrix(bb[,-c(1,2:19)])

rm(aa,bb)
}

# Running Spearman rank correlation between SOI indices and the seasonal precipitation 
raster_list<-list()
for (i in colnames(mat1)){
  cor_cells<-cor(mat2,mat1[,i],method = "spearman")
  xx<-t(rbind(attribute,t(cor_cells)))
  raster_list[i]<- rasterFromXYZ(xx)
}


# Visualizing as a map the resulted correlation coefficients across the study area 
{  
  pal<- c("black", '#053061','#2166ac','#4393c3','#92c5de','#d1e5f0','#fddbc7','#f4a582','#d6604d','#b2182b','#67001f',"black")
  cuts = c(0.6,0.5,0.4,0.3,0.2, 0.1, 0, -0.1, -0.2, -0.3, -0.4, -0.5, -0.6)
  
  x11()
  plot(raster_list[[12]], breaks=cuts, col=pal,
       main="pixel-wise Spearman`s correlation between SOI state in December \n and February-June  precipitation ",
       font.main = 1) 
  plot(region_polygons, lwd=3,border="white", add=T)
}
dev.off() 

## Aggregating resulted Spearman correlation coefficients for each subregion
{
mean_corr<-matrix(nrow = 18, ncol = 1)

 raster_brick<-brick(raster_list)

for(i in region_polygons$Name){
  single_subregion= subset(region_polygons, Name==i)
  subregion_brick<- raster::mask(raster_brick,single_subregion)
  
  
  cc<-as.data.frame(raster::cellStats(subregion_brick,'mean',na.rm=T))
  colnames(cc)<-i
  mean_corr<-cbind(mean_corr,cc)
}


mean_corr<-data.matrix(mean_corr[,-1])
rownames(mean_corr)<-c("Jan", "Feb","Mar", "Apr","May", "Jun",
                       "Jul", "Aug","Sep", "Oct","Nov", "Dec","Jan",
                       "Feb*","Mar*","Apr*","May*","Jun*")

print(round(mean_corr,2)) # Spearman's rank correlation coefficients between SOI and February to June precipitation for all subregions
gridExtra:: grid.table(round(mean_corr,2),theme=ttheme_default(colhead=list(fg_params=list(rot=90)))) 
}

#Visualizing the table as a heatmap 
col_fun = colorRamp2(c(0.6,0.5,0.4,0.3,0.2, 0.1,0,-0.1, -0.2,-0.3,-0.4,-0.5,-0.6),
                     c("black",'#67001f','#b2182b','#d6604d','#f4a582','#fddbc7','white',
                       '#d1e5f0','#92c5de','#4393c3','#2166ac','#053061',"black"))       
x11()

ComplexHeatmap::Heatmap(mean_corr, column_title = "SOI",column_title_gp = gpar(fontsize = 14, fontface = "bold"),
        show_heatmap_legend = FALSE, col = col_fun, rect_gp = gpar(col = "white", lwd = 2),
        show_column_dend=F,show_row_dend=F, #remove dendropaths
        row_order = order(as.numeric(gsub("row", "", rownames(mean_corr)))), #order rows as original
        # column_order = order(as.numeric(gsub("column", "", colnames(mean_corr)))), #order columns as original
        row_names_side = "left",  column_names_side = "top", #location of labels
        width = unit(5, "cm"), height = unit(12, "cm")) #size of the cells

at = c(0.5,0.4,0.3,0.2, 0.1,0,-0.1, -0.2,-0.3,-0.4,-0.5)
lgd=Legend(at = at, title = expression(rho),legend_height = unit(30, "cm"),
           legend_gp = gpar(fill = col_fun(at)),
           labels_gp = gpar(col = "black", font = 1,fontsize=7))
draw(lgd, just = c("right", "centre"))


##########################################################################################
# Assessment of the seasonal precipitation predictability with support vector regression (SVR)
#(using Western Tian-Shan subregion as a case study)

DATA<-merge(seasonal_prcp,indices, by="year")
rm(list=ls()[! ls() %in% c("DATA")])


# Extracting variables for the Western Tian-Shan: 
df<-DATA[,c("West Tian-Shan","l_soi03" , "l_pdo11_lag_1" , "eawr10_lag_1" , "l_qbo08_lag_1" , "sh12_lag_1" , "nao12_lag_1" ,"l_dmi04_lag_1", "amo01")]
colnames(df)[1]<-"seasonal_prcp"
str(df) #the df dataframe now contains timeserie of predictant variable ("seasonal_prcp) and a set of predictor variables (the oscillation indices at their dominant lead times)

# Splitting the data into training and validation samples, by the stratified sampling approach: 
inds <-splitTools:: partition(df$seasonal_prcp, p = c(train = 0.75, valid = 0.25), seed=1)
dataset <- df[inds$train, ]
testdata <- df[inds$valid, ]

# Running SVR (radial basis function kernel) with cost and gamma parameters,
# which were estimated during the calibration process:  

svm_model <-  svm(formula = seasonal_prcp ~., data = dataset, type = "nu-regression", 
                  kernel = "radial",
                  gamma = 0.022, cost = 2.8,  
                  scale = TRUE)
summary(svm_model)


# Performance of the SVR calibrated on the training sample:
predicted_trainset <- predict(svm_model, dataset)

#MAPE
Metrics::mape(dataset$seasonal_prcp,predicted_trainset) 
# Squared coefficient of determination
hydroGOF::br2(predicted_trainset, dataset$seasonal_prcp)
#KGE
hydroGOF:: KGE(predicted_trainset, dataset$seasonal_prcp)


# Evaluation of the SVR model on the validation sample:
predicted_validset <- predict(svm_model, testdata)

#MAPE
Metrics::mape(predicted_validset,testdata$seasonal_prcp) 
# Squared coefficient of determination
hydroGOF::br2(predicted_validset , testdata$seasonal_prcp)
#KGE
hydroGOF:: KGE(predicted_validset , testdata$seasonal_prcp)


# Evaluating the SVR on the full data 
predicted_full <- predict(svm_model, df)
hydroGOF:: ggof(predicted_full, df$seasonal_prcp)


## Assessing predictor importance by Global Sensitivity Analysis:
{
    M <- fit(seasonal_prcp~., data=df, model="svm", type="nu-svr",kernel="rbfdot", scale="all", 
           gamma=svm_model$gamma, cost=svm_model$cost, 
           epsilon=svm_model$epsilon,  nu=svm_model$nu)
  
  VariableImportance <- Importance(M, data=df,method="GSA",
                                   measure = "variance")
  
  L=list(runs=100000,sen=t(VariableImportance$imp),
         sresponses=VariableImportance$sresponses)
  mgraph(L,graph="IMP",leg=names(df),col="gray",Grid=0)
}

# To check performance of the SVR models for other subregions, the set of selected predictors in "df" should be modified
# so that it includes the oscillation indices  relevant to target subregion. Please check Table 3 in the original 
# manuscript for exact set of climate oscillations and their dominant lead times for each subregion, and change line 303 accordingly.
# The SVR cost and gamma coefficients (line 317) are also determined for each subregion separately, and can be retrieved 
# from "SVR_parameters.doc" file. 
